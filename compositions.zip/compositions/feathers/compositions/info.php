<?php
return array(
    "name"          => __("Compositions", "compositions"),
    "url"           => "http://chyrplite.net/",
    "version"       => "2023.09",
    "description"   => __("Post compositions, prose, short stories, songlyrics etc.", "compositions"),
    "author"        => array(
        "name"      => "Erwin Maas",
        "url"       => "https://exdomo.com"
    )
);